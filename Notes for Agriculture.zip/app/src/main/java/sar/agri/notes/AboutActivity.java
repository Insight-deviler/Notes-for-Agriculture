package sar.agri.notes;

import androidx.appcompat.app.AppCompatActivity;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.graphics.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.text.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import android.widget.TextView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.AdListener;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.widget.AdapterView;
import android.graphics.Typeface;

public class AboutActivity extends AppCompatActivity {
	
	
	private String sub = "";
	private String text = "";
	
	private ArrayList<HashMap<String, Object>> About = new ArrayList<>();
	
	private LinearLayout linear7;
	private ListView listview2;
	private AdView adview5;
	private TextView textview2;
	
	private InterstitialAd ia;
	private AdListener _ia_ad_listener;
	private AlertDialog.Builder credits;
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.about);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		listview2 = (ListView) findViewById(R.id.listview2);
		adview5 = (AdView) findViewById(R.id.adview5);
		textview2 = (TextView) findViewById(R.id.textview2);
		credits = new AlertDialog.Builder(this);
		
		listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (_position == 0) {
					Intent i = new Intent(Intent.ACTION_SEND); i.setType("message/rfc822"); i.putExtra(Intent.EXTRA_EMAIL , new String[]{"insightagri10@gmail.com"}); i.putExtra(Intent.EXTRA_SUBJECT, "Feedback about Agri notes"); i.putExtra(Intent.EXTRA_TEXT , " "); try { startActivity(Intent.createChooser(i, "Send mail...")); } catch (android.content.ActivityNotFoundException ex) { Toast.makeText(AboutActivity.this, "There are no email clients installed.", Toast.LENGTH_SHORT).show(); }
					
				}
				if (_position == 1) {
					 Intent i = new Intent(android.content.Intent.ACTION_SEND); i.setType("text/plain"); i.putExtra(android.content.Intent.EXTRA_SUBJECT, sub); i.putExtra(android.content.Intent.EXTRA_TEXT, text); startActivity(Intent.createChooser(i,"Share using"));
					
					
					sub = "Notes for Agri";
					text = "Hi I'm using Notes for Agri. It contains one words from all the course.  You can also contribute your one words by logging in. Install it from the link below.\n\nhttps://insight-deviler.github.io/Notes-for-Agriculture/";
				}
				if (_position == 2) {
					credits.setTitle("Credits");
					credits.setMessage("This app is owned by Sarath S\n\nApp icon or logo by Arun Kumar J\n\nIcons by Icons8\n\nDrawer image by Canva\n");
					credits.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					credits.create().show();
				}
				if (_position == 3) {
					i.setAction(Intent.ACTION_VIEW);
					i.setData(Uri.parse("https://insight-deviler.github.io/Notes-for-Agriculture/"));
					startActivity(i);
				}
			}
		});
		
		_ia_ad_listener = new AdListener() {
			@Override
			public void onAdLoaded() {
				ia.show();
			}
			
			@Override
			public void onAdFailedToLoad(int _param1) {
				final int _errorCode = _param1;
				SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(_errorCode)));
			}
			
			@Override
			public void onAdOpened() {
				
			}
			
			@Override
			public void onAdClosed() {
				
			}
		};
	}
	private void initializeLogic() {
		adview5.loadAd(new AdRequest.Builder().addTestDevice("A08C74C00AD8B6")
		.build());
		ia = new InterstitialAd(getApplicationContext());
		ia.setAdListener(_ia_ad_listener);
		ia.setAdUnitId("ca-app-pub-978614");
		ia.loadAd(new AdRequest.Builder().addTestDevice("FA843668B6")
		.build());
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sansbold.ttf"), 1);
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("a", "Feedback");
			About.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("a", "Share");
			About.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("a", "Credits");
			About.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("a", "Privacy Policy");
			About.add(_item);
		}
		
		listview2.setAdapter(new Listview2Adapter(About));
		((BaseAdapter)listview2.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	@Override
	public void onBackPressed() {
		ia.show();
		finish();
	}
	public class Listview2Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Listview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.about_main, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			final TextView textview6 = (TextView) _v.findViewById(R.id.textview6);
			
			textview6.setText(About.get((int)_position).get("a").toString());
			textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/sansregular.ttf"), 0);
			
			return _v;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}
